import { useEffect, useState, type FormEvent, type ReactNode } from 'react';
import { Pencil, Plus, Trash2 } from 'lucide-react';
import { initialResources, type ResourceRow, type Service } from '@/data/demoData';
import { DataTable, type Column } from '@/components/data-table';
import { Layout } from '@/components/layout';
import { ContextBadge, PageHeader } from '@/components/page-header';
import { SearchField } from '@/components/search-field';
import { EmptyState } from '@/components/empty-state';
import { Ltr } from '@/components/ltr';
import { ErrorState } from '@/components/error-state';
import { Money } from '@/components/money';
import { StatusBadge } from '@/components/status-badge';
import { TableSkeleton } from '@/components/skeleton';
import { useMockStatus } from '@/hooks/use-mock-loading';
import type { Language, TranslationKey } from '@/i18n/translations';
import { statusLabel, translateValue } from '@/i18n/labels';
import type { Formatters } from '@/i18n/format';
import { useFormat, useT } from '@/i18n/use-i18n';
import { notify } from '@/store/notificationStore';
import { useDemoState } from '@/store/demoStore';

// Stored values stay in English; labels are translated on display (see `translateValue`).
const OPTIONS = {
  airline: ['Saudia', 'Flynas', 'Flyadeal', 'Emirates', 'Qatar Airways'],
  route: ['RUH → JED', 'RUH → DXB', 'JED → CAI', 'RUH → AMM'],
  city: ['Riyadh', 'Jeddah', 'Dubai', 'Amman', 'Doha', 'Cairo'],
  room: ['King Suite', 'Deluxe', 'Twin Room', 'Standard Room'],
  availability: ['Available Now', 'Limited', 'Booked'],
  hotelName: ['Hilton Garden', 'The Boulevard', 'Mövenpick'],
  carModel: ['Toyota Camry', 'Kia Carnival', 'BMW 3 Series', 'Nissan Patrol', 'Hyundai Sonata'],
  status: ['Available', 'Limited', 'Scheduled', 'Boarding', 'Booked'],
};

type Kind = Service;
type ModalMode = 'add' | 'edit' | 'remove';
type ResourceDraft = { id: string; airline: string; route: string; city: string; room: string; location: string; availability: string; price: string; status: string };

const heading: Record<Kind, TranslationKey> = { flight: 'flightManagement', hotel: 'hotelManagement', car: 'carManagement' };
const singular: Record<Kind, TranslationKey> = { flight: 'flightSingular', hotel: 'hotelSingular', car: 'carSingular' };
const sectionKey: Record<Kind, TranslationKey> = { flight: 'flights', hotel: 'hotels', car: 'cars' };
const subtitleKey: Record<Kind, TranslationKey> = { flight: 'flightsSubtitle', hotel: 'hotelsSubtitle', car: 'carsSubtitle' };
const actionKey: Record<ModalMode, TranslationKey> = { add: 'add', edit: 'edit', remove: 'remove' };
const noticeKeys: Record<ModalMode, { title: TranslationKey; message: TranslationKey }> = {
  add: { title: 'recordAddedTitle', message: 'recordAdded' },
  edit: { title: 'recordUpdatedTitle', message: 'recordUpdated' },
  remove: { title: 'recordRemovedTitle', message: 'recordRemoved' },
};

function createDraft(row?: ResourceRow): ResourceDraft {
  return { id: row?.id ?? '', airline: row?.airline ?? '', route: row?.route ?? '', city: row?.city ?? '', room: row?.room ?? '', location: row?.location ?? '', availability: row?.availability ?? '', price: String(row?.price ?? 150), status: row?.status ?? '' };
}

function toRow(kind: Kind, draft: ResourceDraft): ResourceRow {
  const base = { id: draft.id.trim(), price: Number(draft.price), status: draft.status.trim() || 'Available' };
  if (kind === 'flight') return { ...base, airline: draft.airline.trim(), route: draft.route.trim() };
  if (kind === 'hotel') return { ...base, city: draft.city.trim(), room: draft.room.trim() };
  return { ...base, location: draft.location.trim(), availability: draft.availability.trim() };
}

function getRowDetails(kind: Kind, row: ResourceRow, language: Language): string {
  if (kind === 'flight') return translateValue(row.route ?? '', language);
  if (kind === 'hotel') return `${translateValue(row.city ?? '', language)} · ${translateValue(row.room ?? '', language)}`;
  return `${translateValue(row.location ?? '', language)} · ${translateValue(row.availability ?? '', language)}`;
}

export default function AdminResource({ kind }: { kind: Kind }) {
  const t = useT();
  const format = useFormat();
  const { settings } = useDemoState();
  const lang = settings.language;
  // TODO / INTEGRATION POINT
  // INTEGRATION POINT: Connect Saud's Flight & Booking APIs here
  // Flights = Saud. Hotels and Cars = Mohammed (INTEGRATION POINT: Connect Mohammed's Auth, Hotel & Car APIs here). Add/Edit/Remove below should call the matching endpoints.
  const [rows, setRows] = useState<ResourceRow[]>(initialResources[kind]);
  const [query, setQuery] = useState('');
  const [searchOpen, setSearchOpen] = useState(false);
  const [modal, setModal] = useState<ModalMode | null>(null);
  const [selectedId, setSelectedId] = useState('');
  const [draft, setDraft] = useState<ResourceDraft>(() => createDraft());
  const [formError, setFormError] = useState('');
  const { status: loadStatus, empty: forceEmpty, retry } = useMockStatus(kind);

  const labels = kind === 'flight' ? [t('totalFlights'), t('flightRevenue'), t('activeUsers')] : kind === 'hotel' ? [t('totalRooms'), t('hotelRevenue'), t('guests')] : [t('totalCars'), t('carsRevenue'), t('availableCars')];
  const needle = query.toLowerCase();
  const filtered = (forceEmpty ? [] : rows).filter((row) => `${row.id} ${translateValue(row.id, lang)} ${translateValue(row.airline ?? '', lang)} ${row.airline ?? ''} ${getRowDetails(kind, row, lang)}`.toLowerCase().includes(needle));
  const suggestions = query.trim() ? filtered.slice(0, 6) : [];
  const displayId = (row: ResourceRow) => kind === 'flight' ? <Ltr>{row.id}</Ltr> : translateValue(row.id, lang);
  const columns = resourceColumns({
    kind, t, lang, format, displayId,
    onEdit: (id) => openModal('edit', id),
    onRemove: (id) => openModal('remove', id),
  });

  useEffect(() => {
    setRows(initialResources[kind]);
    setQuery('');
    setModal(null);
    setSelectedId('');
    setFormError('');
  }, [kind]);

  useEffect(() => {
    if (!modal) return;
    const closeOnEscape = (event: KeyboardEvent) => { if (event.key === 'Escape') closeModal(); };
    window.addEventListener('keydown', closeOnEscape);
    return () => window.removeEventListener('keydown', closeOnEscape);
  }, [modal]);

  function closeModal() {
    setModal(null);
    setSelectedId('');
    setFormError('');
  }

  function openModal(mode: ModalMode, id = '') {
    setModal(mode);
    setSelectedId(id);
    setDraft(createDraft(rows.find((row) => row.id === id)));
    setFormError('');
  }

  function selectRow(id: string) {
    setSelectedId(id);
    setDraft(createDraft(rows.find((row) => row.id === id)));
    setFormError('');
  }

  function updateDraft(field: keyof ResourceDraft, value: string) {
    setDraft((current) => ({ ...current, [field]: value }));
    setFormError('');
  }

  function saveRecord(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!modal) return;
    if (!selectedId && modal !== 'add') return setFormError(t('selectRecordFirst'));
    if (modal === 'add' && !draft.id.trim()) return setFormError(t('requiredField'));
    if (kind === 'flight' && modal !== 'remove' && !draft.airline) return setFormError(t('requiredField'));
    if (modal === 'add' && rows.some((row) => row.id.toLowerCase() === draft.id.trim().toLowerCase())) return setFormError(t('duplicateRecord'));
    if (modal !== 'remove' && (!draft.price.trim() || Number.isNaN(Number(draft.price)) || !draft.status.trim())) return setFormError(t('requiredField'));

    const recordId = modal === 'add' ? draft.id.trim() : selectedId;
    if (modal === 'remove') setRows((current) => current.filter((row) => row.id !== selectedId));
    else if (modal === 'add') setRows((current) => [...current, toRow(kind, draft)]);
    else setRows((current) => current.map((row) => row.id === selectedId ? toRow(kind, { ...draft, id: selectedId }) : row));

    // The admin action succeeded: show the toast (and add it to the bell menu).
    notify({
      tone: modal === 'remove' ? 'warning' : 'success',
      titleKey: noticeKeys[modal].title,
      messageKey: noticeKeys[modal].message,
      params: { noun: { key: singular[kind] }, id: recordId },
    });
    closeModal();
  }

  function goToSuggestion(id: string) {
    setQuery(id);
    setSearchOpen(false);
  }

  const noun = t(singular[kind]);
  const title = modal ? `${t(actionKey[modal])} ${noun}` : '';

  return (
    <Layout>
      <section className="page-panel">
        <PageHeader
          section={t(sectionKey[kind])}
          title={t(heading[kind])}
          subtitle={t(subtitleKey[kind])}
          badges={<ContextBadge>{t('recordsCount', { count: format.number(rows.length) })}</ContextBadge>}
          actions={
            <SearchField value={query} onChange={(value) => { setQuery(value); setSearchOpen(true); }} placeholder={t('search')} testId={`input-${kind}-search`}
              onFocus={() => setSearchOpen(true)} onBlur={() => setTimeout(() => setSearchOpen(false), 120)}>
              {searchOpen && query.trim() && (
                <SearchSuggestions kind={kind} rows={suggestions} language={lang} onPick={goToSuggestion} emptyText={t('noResults')} displayId={displayId} />
              )}
            </SearchField>
          }
        />

        <div className="metric-grid">
          <Metric label={labels[0]} value={format.number(1284)} />
          <Metric label={labels[1]} value={<Money usd={142670} />} />
          <Metric label={labels[2]} value={format.number(3280)} />
        </div>

        <div className="action-row">
          <button className="button button-soft" onClick={() => openModal('add')} data-testid={`button-add-${kind}`}><Plus size={15} aria-hidden="true" />{t('add')} {noun}</button>
          <button className="button button-soft" onClick={() => openModal('edit')} data-testid={`button-edit-${kind}`}><Pencil size={15} aria-hidden="true" />{t('edit')} {noun}</button>
          <button className="button button-soft" onClick={() => openModal('remove')} data-testid={`button-remove-${kind}`}><Trash2 size={15} aria-hidden="true" />{t('remove')} {noun}</button>
        </div>

        <section className="section-card">
          <div className="table-wrap" tabIndex={0} role="region" aria-label={t(heading[kind])}>
            {loadStatus === 'loading' ? <TableSkeleton columns={columns.length} /> : loadStatus === 'error' ? <ErrorState onRetry={retry} /> : <>
            <DataTable caption={t(heading[kind])} columns={columns} rows={filtered} getKey={(row) => row.id} minWidth={1000} />
            {filtered.length === 0 && <EmptyState message={t('noResults')} actionLabel={query ? t('clearSearch') : undefined} onAction={() => setQuery('')} />}
            </>}
          </div>
        </section>
      </section>

      {modal && (
        <div className="modal-backdrop" role="presentation" onMouseDown={(event) => event.target === event.currentTarget && closeModal()}>
          <section className="modal-card" role="dialog" aria-modal="true" aria-labelledby="resource-modal-title">
            <div className="modal-header">
              <div><span className="modal-eyebrow">{t(heading[kind])}</span><h2 id="resource-modal-title">{title}</h2></div>
              <button className="modal-close" onClick={closeModal} aria-label={t('close')}>×</button>
            </div>
            <form className="modal-form" onSubmit={saveRecord}>
              {modal !== 'add' && (
                <label className="modal-field">
                  <span>{t('chooseRecord')}</span>
                  <select className="select-control" value={selectedId} onChange={(event) => selectRow(event.target.value)} aria-label={t('chooseRecord')} data-testid={`select-${modal}-${kind}-record`}>
                    <option value="">{t('selectRecord')}</option>
                    {rows.map((row) => <option value={row.id} key={row.id}>{translateValue(row.id, lang)} — {getRowDetails(kind, row, lang)}</option>)}
                  </select>
                </label>
              )}
              {modal !== 'remove' && (
                <div className="modal-fields-grid">
                  {modal === 'add' && (kind === 'flight'
                    ? <Field label={t('flightNumber')} value={draft.id} onChange={(value) => updateDraft('id', value)} required ltr />
                    : <SelectField label={kind === 'hotel' ? t('hotelName') : t('carModel')} value={draft.id} onChange={(value) => updateDraft('id', value)} options={kind === 'hotel' ? OPTIONS.hotelName : OPTIONS.carModel} getLabel={(v) => translateValue(v, lang)} placeholder={t('select')} required />)}
                  {kind === 'flight' && <SelectField label={t('airline')} value={draft.airline} onChange={(value) => updateDraft('airline', value)} options={OPTIONS.airline} getLabel={(v) => translateValue(v, lang)} placeholder={t('select')} required />}
                  {kind === 'flight' && <SelectField label={t('route')} value={draft.route} onChange={(value) => updateDraft('route', value)} options={OPTIONS.route} getLabel={(v) => translateValue(v, lang)} placeholder={t('select')} />}
                  {kind === 'hotel' && (
                    <>
                      <SelectField label={t('city')} value={draft.city} onChange={(value) => updateDraft('city', value)} options={OPTIONS.city} getLabel={(v) => translateValue(v, lang)} placeholder={t('select')} />
                      <SelectField label={t('roomType')} value={draft.room} onChange={(value) => updateDraft('room', value)} options={OPTIONS.room} getLabel={(v) => translateValue(v, lang)} placeholder={t('select')} />
                    </>
                  )}
                  {kind === 'car' && (
                    <>
                      <SelectField label={t('location')} value={draft.location} onChange={(value) => updateDraft('location', value)} options={OPTIONS.city} getLabel={(v) => translateValue(v, lang)} placeholder={t('select')} />
                      <SelectField label={t('availability')} value={draft.availability} onChange={(value) => updateDraft('availability', value)} options={OPTIONS.availability} getLabel={(v) => translateValue(v, lang)} placeholder={t('select')} />
                    </>
                  )}
                  <Field label={`${t('price')} (USD)`} type="number" min="0" value={draft.price} onChange={(value) => updateDraft('price', value)} required ltr />
                  <SelectField label={t('status')} value={draft.status} onChange={(value) => updateDraft('status', value)} options={OPTIONS.status} getLabel={(v) => statusLabel(v, t)} placeholder={t('select')} />
                </div>
              )}
              {modal === 'remove' && <p className="modal-warning">{selectedId ? <>{t('removeRecordConfirm')} <bdi>{translateValue(selectedId, lang)}</bdi></> : t('selectRecordFirst')}</p>}
              {formError && <p className="form-error" role="alert">{formError}</p>}
              <div className="modal-actions">
                <button type="button" className="button button-ghost" onClick={closeModal}>{t('cancel')}</button>
                <button type="submit" className={`button ${modal === 'remove' ? 'button-danger' : 'button-primary'}`} data-testid={`button-confirm-${modal}-${kind}`}>{modal === 'remove' ? t('remove') : modal === 'add' ? t('add') : t('saveChanges')}</button>
              </div>
            </form>
          </section>
        </div>
      )}
    </Layout>
  );
}

type ColumnOptions = {
  kind: Kind;
  t: ReturnType<typeof useT>;
  lang: Language;
  format: Formatters;
  displayId: (row: ResourceRow) => ReactNode;
  onEdit: (id: string) => void;
  onRemove: (id: string) => void;
};

/** Edit / Remove buttons of one row. */
function RowActions({ kind, row, t, onEdit, onRemove }: Pick<ColumnOptions, 'kind' | 't' | 'onEdit' | 'onRemove'> & { row: ResourceRow }) {
  return (
    <div className="row-actions flex flex-row items-center justify-center gap-3">
      <button className="button button-ghost" onClick={() => onEdit(row.id)} data-testid={`button-edit-${kind}-${row.id}`}><Pencil size={14} aria-hidden="true" />{t('edit')}</button>
      <button className="button button-ghost button-ghost-danger" onClick={() => onRemove(row.id)} data-testid={`button-remove-${kind}-${row.id}`}><Trash2 size={14} aria-hidden="true" />{t('remove')}</button>
    </div>
  );
}

/**
 * Columns of the Flights / Hotels / Cars tables. Each table has exactly 5 columns:
 * name or number | details | price | status | actions. The header and the cells come from this one list.
 * Flights keep the airline as a small second line under the flight number (no extra column).
 */
function resourceColumns({ kind, t, lang, displayId, onEdit, onRemove }: ColumnOptions): Column<ResourceRow>[] {
  const nameHeader = kind === 'flight' ? t('flightNumber') : kind === 'hotel' ? t('hotelName') : t('carModel');
  const detailsHeader = kind === 'flight' ? t('route') : kind === 'hotel' ? t('cityRoom') : t('locationAvailability');
  // Flights: number | route | price | status | actions. Hotels / Cars: name | details | price | status | actions.
  const width = kind === 'flight' ? ['18%', '24%', '14%', '14%', '30%'] : ['20%', '24%', '14%', '14%', '28%'];
  return [
    {
      key: 'name', width: width[0], header: nameHeader,
      cell: (row) => (
        <>
          {displayId(row)}
          {kind === 'flight' && row.airline && <span className="cell-sub">{translateValue(row.airline, lang)}</span>}
        </>
      ),
    },
    { key: 'details', width: width[1], header: detailsHeader, cell: (row) => getRowDetails(kind, row, lang) },
    { key: 'price', width: width[2], header: t('price'), align: 'end', cell: (row) => <Money usd={row.price} /> },
    { key: 'status', width: width[3], header: t('status'), align: 'center', cell: (row) => <StatusBadge status={row.status} /> },
    { key: 'actions', width: width[4], header: t('actions'), align: 'end', cell: (row) => <RowActions kind={kind} row={row} t={t} onEdit={onEdit} onRemove={onRemove} /> },
  ];
}

/** Dropdown under the page search: up to 6 matching rows, or a "no results" line. */
function SearchSuggestions({ kind, rows, language, onPick, emptyText, displayId }: { kind: Kind; rows: ResourceRow[]; language: Language; onPick: (id: string) => void; emptyText: string; displayId: (row: ResourceRow) => ReactNode }) {
  if (rows.length === 0) return <div className="search-suggestions"><span className="search-suggestion-empty">{emptyText}</span></div>;
  return (
    <div className="search-suggestions" role="listbox">
      {rows.map((row) => (
        <button key={row.id} className="search-suggestion" onMouseDown={() => onPick(row.id)} data-testid={`suggestion-${kind}-${row.id}`}>
          <span className="search-suggestion-id">{displayId(row)}</span>
          <span className="search-suggestion-details">{getRowDetails(kind, row, language)}</span>
        </button>
      ))}
    </div>
  );
}

function Field({ label, value, onChange, type = 'text', min, required = false, ltr = false }: { label: string; value: string; onChange: (value: string) => void; type?: string; min?: string; required?: boolean; ltr?: boolean }) {
  return <label className="modal-field"><span>{label}</span><input className="input-control" type={type} min={min} value={value} onChange={(event) => onChange(event.target.value)} required={required} dir={ltr ? 'ltr' : undefined} /></label>;
}

function Metric({ label, value }: { label: string; value: ReactNode }) {
  return <div className="metric-card"><span className="metric-label">{label}</span><strong className="metric-value">{value}</strong></div>;
}

function SelectField({ label, value, onChange, options, getLabel, placeholder, required = false }: { label: string; value: string; onChange: (value: string) => void; options: string[]; getLabel: (value: string) => string; placeholder: string; required?: boolean }) {
  return (
    <label className="modal-field">
      <span>{label}</span>
      <select className="select-control" value={value} onChange={(event) => onChange(event.target.value)} required={required}>
        <option value="">{placeholder}</option>
        {options.map((option) => <option key={option} value={option}>{getLabel(option)}</option>)}
      </select>
    </label>
  );
}
