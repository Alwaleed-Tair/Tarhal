import { CardSkeleton, ListingView, type SortOption } from '@/components/listing-view';
import { HotelCard } from '@/components/listing-cards';
import { PublicLayout } from '@/components/public-layout';
import { hotelListings, type Hotel } from '@/data/listings';
import { useT } from '@/i18n/use-i18n';

const SORTS: SortOption<Hotel>[] = [
  { value: 'rating', labelKey: 'sortRating', compare: (a, b) => b.rating - a.rating },
  { value: 'name', labelKey: 'sortName', compare: (a, b) => a.name.localeCompare(b.name) },
];
const searchText = (hotel: Hotel) => `${hotel.name} ${hotel.nameAr} ${hotel.address} ${hotel.addressAr}`;

// TODO / INTEGRATION POINT
// INTEGRATION POINT: Connect Mohammed's Auth, Hotel & Car APIs here
export default function Stays() {
  const t = useT();
  return (
    <PublicLayout>
      <ListingView title={t('hotels')} subtitle={t('staysSubtitle')} items={hotelListings} getKey={(hotel) => hotel.id} searchText={searchText}
        sorts={SORTS} renderItem={(hotel) => <HotelCard hotel={hotel} />} skeleton={<CardSkeleton image />} />
    </PublicLayout>
  );
}
