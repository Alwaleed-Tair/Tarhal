import { CarCard } from '@/components/listing-cards';
import { CardSkeleton, ListingView, type SortOption } from '@/components/listing-view';
import { PublicLayout } from '@/components/public-layout';
import { carListings, type Car } from '@/data/listings';
import { useT } from '@/i18n/use-i18n';

const SORTS: SortOption<Car>[] = [
  { value: 'priceAsc', labelKey: 'sortPriceAsc', compare: (a, b) => a.pricePerDay - b.pricePerDay },
  { value: 'priceDesc', labelKey: 'sortPriceDesc', compare: (a, b) => b.pricePerDay - a.pricePerDay },
  { value: 'newest', labelKey: 'sortNewest', compare: (a, b) => b.year - a.year },
];
const searchText = (car: Car) => `${car.make} ${car.model} ${car.year} ${car.transmission}`;

// TODO / INTEGRATION POINT
// INTEGRATION POINT: Connect Mohammed's Auth, Hotel & Car APIs here
export default function Rentals() {
  const t = useT();
  return (
    <PublicLayout>
      <ListingView title={t('cars')} subtitle={t('rentalsSubtitle')} items={carListings} getKey={(car) => car.id} searchText={searchText}
        sorts={SORTS} renderItem={(car) => <CarCard car={car} />} skeleton={<CardSkeleton />} />
    </PublicLayout>
  );
}
