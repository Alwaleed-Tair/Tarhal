import { useLocation } from 'wouter';
import { routes } from '@/config/routes';
import { logout } from '@/store/authStore';
import { notify } from '@/store/notificationStore';

export function useSignOut() {
  const [, setLocation] = useLocation();
  return () => {
    logout();
    notify({ tone: 'info', titleKey: 'logoutTitle', messageKey: 'logoutMessage' });
    setLocation(routes.home);
  };
}
