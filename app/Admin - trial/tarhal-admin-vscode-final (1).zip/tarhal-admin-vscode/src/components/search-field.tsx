import type { ReactNode } from 'react';
import { Search } from 'lucide-react';

type SearchFieldProps = {
  value: string;
  onChange: (value: string) => void;
  placeholder: string;
  testId: string;
  onFocus?: () => void;
  onBlur?: () => void;
  /** Optional dropdown (suggestions) rendered under the field. */
  children?: ReactNode;
};

/** Page-level search box with the magnifier inside the field, same look as the top bar search. */
export function SearchField({ value, onChange, placeholder, testId, onFocus, onBlur, children }: SearchFieldProps) {
  return (
    <div className="page-search-wrap">
      <label className="global-search page-search">
        <Search size={15} aria-hidden="true" />
        <input type="search" value={value} onChange={(event) => onChange(event.target.value)} onFocus={onFocus} onBlur={onBlur}
          placeholder={placeholder} aria-label={placeholder} data-testid={testId} />
      </label>
      {children}
    </div>
  );
}
